package com.example.weatherapp;

public class userinfo {
 public String ml;

    public userinfo(String ml) {
        this.ml = ml;
    }

    public userinfo(){

    }





}
